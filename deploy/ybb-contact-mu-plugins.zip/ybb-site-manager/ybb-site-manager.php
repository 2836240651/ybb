<?php
/**
 * Plugin Name: YBB Site Manager
 * Description: Unified site configuration — navigation, announcements, hero, home modules, deploy queue.
 * Version: 1.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('YBB_SM_VERSION', '1.7.0');
define('YBB_SM_DIR', __DIR__);
define('YBB_SM_OPTION', 'ybb_site_manager_settings');

require_once YBB_SM_DIR . '/includes/defaults.php';
require_once YBB_SM_DIR . '/includes/class-settings.php';
require_once YBB_SM_DIR . '/includes/class-sanitize.php'; // before admin_init
require_once YBB_SM_DIR . '/includes/modules/navigation.php';
require_once YBB_SM_DIR . '/includes/modules/announcements.php';
require_once YBB_SM_DIR . '/includes/modules/hero.php';
require_once YBB_SM_DIR . '/includes/modules/blog.php';
require_once YBB_SM_DIR . '/includes/modules/pdp.php';
require_once YBB_SM_DIR . '/includes/modules/products.php';
require_once YBB_SM_DIR . '/includes/modules/product-index.php';
require_once YBB_SM_DIR . '/includes/modules/home.php';
require_once YBB_SM_DIR . '/includes/modules/brand.php';
require_once YBB_SM_DIR . '/includes/modules/contact.php';
require_once YBB_SM_DIR . '/includes/modules/video.php';
require_once YBB_SM_DIR . '/includes/modules/featured.php';
require_once YBB_SM_DIR . '/includes/modules/deploy-queue.php';
require_once YBB_SM_DIR . '/includes/modules/audit-log.php';
require_once YBB_SM_DIR . '/includes/class-rest.php';
require_once YBB_SM_DIR . '/includes/migrate.php';
require_once YBB_SM_DIR . '/includes/admin/tab-products.php';
require_once YBB_SM_DIR . '/includes/admin/page.php';

add_action('plugins_loaded', 'ybb_sm_maybe_migrate', 5);

add_action('admin_menu', function () {
    add_menu_page(
        'YBB 站点管理',
        'YBB 站点管理',
        'manage_options',
        'ybb-site-manager',
        'ybb_sm_render_admin_page',
        'dashicons-admin-site',
        58
    );
});

add_action('admin_init', function () {
    register_setting('ybb_sm_group', YBB_SM_OPTION, [
        'type' => 'array',
        'sanitize_callback' => 'ybb_sm_sanitize_settings',
        'default' => ybb_sm_defaults(),
    ]);
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_ybb-site-manager') {
        return;
    }
    wp_enqueue_media();
    wp_register_script('ybb-sm-admin', false, ['jquery'], YBB_SM_VERSION, true);
    wp_enqueue_script('ybb-sm-admin');
    wp_add_inline_script('ybb-sm-admin', 'window.ybbSmOptionName = ' . wp_json_encode(YBB_SM_OPTION) . ';');
    wp_add_inline_script('ybb-sm-admin', <<<'JS'
jQuery(function ($) {
  $(document).on('click', '.ybb-sm-pick-image', function (e) {
    e.preventDefault();
    var $btn = $(this);
    var $input = $($btn.data('target'));
    var frame = wp.media({ title: 'Select image', multiple: false, library: { type: 'image' } });
    frame.on('select', function () {
      var att = frame.state().get('selection').first().toJSON();
      $input.val(att.url || '');
    });
    frame.open();
  });
  $(document).on('click', '.ybb-sm-add-row', function (e) {
    e.preventDefault();
    var $table = $($btn = $(this)).closest('.ybb-sm-repeater').find('tbody');
    var tpl = $($btn.data('template')).html();
    var idx = $table.find('tr').length;
    $table.append(tpl.replace(/__INDEX__/g, String(idx)));
  });
  $(document).on('click', '.ybb-sm-remove-row', function (e) {
    e.preventDefault();
    $(this).closest('tr').remove();
  });
});
JS
    );
});
