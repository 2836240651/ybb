<?php

if (!defined('ABSPATH')) {
    exit;
}

const YBB_SM_PRODUCT_OVERRIDES_OPTION = 'ybb_sm_product_overrides';

function ybb_sm_products_defaults(): array
{
    return [
        'enabled' => true,
        'overrides' => [],
        'pdp' => ybb_sm_pdp_defaults(),
        'productIndex' => [
            'lastBuiltAt' => '',
            'lastBuildId' => '',
            'productCount' => 0,
        ],
    ];
}

function ybb_sm_products_module(): array
{
    $data = ybb_sm_get_module('products');
    if (!is_array($data) || $data === []) {
        $data = ybb_sm_products_defaults();
    } else {
        $data = array_replace(ybb_sm_products_defaults(), $data);
    }

    $data['overrides'] = ybb_sm_product_overrides_all();

    return $data;
}

/** @return array<string, array<string, mixed>> */
function ybb_sm_product_overrides_all(): array
{
    $stored = get_option(YBB_SM_PRODUCT_OVERRIDES_OPTION, null);
    if (is_array($stored) && count($stored) > 0) {
        return $stored;
    }

    $legacy = ybb_sm_get_module('products');
    $legacyOverrides = is_array($legacy['overrides'] ?? null) ? $legacy['overrides'] : [];
    if ($legacyOverrides !== []) {
        ybb_sm_product_overrides_save($legacyOverrides);

        return $legacyOverrides;
    }

    return [];
}

/** @param array<string, array<string, mixed>> $overrides */
function ybb_sm_product_overrides_save(array $overrides): bool
{
    return update_option(YBB_SM_PRODUCT_OVERRIDES_OPTION, $overrides, false);
}

function ybb_sm_product_handle_from_sku(string $sku): string
{
    return sanitize_title(strtolower(trim($sku)));
}

function ybb_sm_product_override_get(string $handle): array
{
    $handle = sanitize_title($handle);
    if ($handle === '') {
        return ybb_sm_product_override_defaults();
    }

    $module = ybb_sm_products_module();
    $row = $module['overrides'][$handle] ?? [];

    return ybb_sm_product_override_normalize($row);
}

/** @return array<string, mixed> */
function ybb_sm_product_override_defaults(): array
{
    return [
        'titleZh' => '',
        'titleJa' => '',
        'frontHidden' => false,
        'descriptionZh' => '',
        'descriptionJa' => '',
        'hideDescription' => false,
        'hideAdditionalInfo' => false,
    ];
}

/** @param array<string, mixed> $row */
function ybb_sm_product_override_normalize(array $row): array
{
    return [
        'titleZh' => (string) ($row['titleZh'] ?? ''),
        'titleJa' => (string) ($row['titleJa'] ?? ''),
        'frontHidden' => !empty($row['frontHidden']),
        'descriptionZh' => (string) ($row['descriptionZh'] ?? ''),
        'descriptionJa' => (string) ($row['descriptionJa'] ?? ''),
        'hideDescription' => !empty($row['hideDescription']),
        'hideAdditionalInfo' => !empty($row['hideAdditionalInfo']),
    ];
}

/** @return array<int, array<string, mixed>> */
function ybb_sm_product_additional_rows(WC_Product $product): array
{
    $rows = [];
    $weight = $product->get_weight();
    if ($weight !== '' && (float) $weight > 0) {
        $rows[] = [
            'key' => 'weight',
            'label' => __('Weight', 'ybb-site-manager'),
            'value' => function_exists('wc_format_weight')
                ? wc_format_weight((float) $weight)
                : (string) $weight,
            'href' => null,
        ];
    }

    foreach ($product->get_attributes() as $attribute) {
        if (!$attribute->get_visible()) {
            continue;
        }

        $name = $attribute->get_name();
        $label = wc_attribute_label($name, $product);
        if ($attribute->is_taxonomy()) {
            $terms = wc_get_product_terms($product->get_id(), $name, ['fields' => 'all']);
            $names = [];
            $termSlug = '';
            foreach ($terms as $term) {
                if ($term instanceof WP_Term) {
                    $names[] = $term->name;
                    if ($termSlug === '') {
                        $termSlug = $term->slug;
                    }
                }
            }
            $value = implode(', ', $names);
            if ($value === '') {
                continue;
            }
            $rows[] = [
                'key' => (string) $name,
                'label' => (string) $label,
                'value' => $value,
                'href' => null,
                'taxonomy' => (string) $name,
                'termSlug' => $termSlug,
            ];
        } else {
            $options = $attribute->get_options();
            $value = is_array($options) ? implode(', ', array_map('strval', $options)) : (string) $options;
            if ($value === '') {
                continue;
            }
            $rows[] = [
                'key' => sanitize_title((string) $name),
                'label' => (string) $label,
                'value' => $value,
                'href' => null,
            ];
        }
    }

    return $rows;
}

/** @return array{visible:bool,html:array{en:string,zh:string,ja:string}} */
function ybb_sm_product_description_payload(WC_Product $product, array $override): array
{
    $en = wp_kses_post((string) $product->get_description());
    $zh = trim((string) ($override['descriptionZh'] ?? ''));
    $ja = trim((string) ($override['descriptionJa'] ?? ''));
    $html = [
        'en' => $en,
        'zh' => $zh !== '' ? wp_kses_post($zh) : $en,
        'ja' => $ja !== '' ? wp_kses_post($ja) : $en,
    ];
    $visible = empty($override['hideDescription']);
    if ($visible) {
        $visible = false;
        foreach ($html as $part) {
            if (wp_strip_all_tags((string) $part) !== '') {
                $visible = true;
                break;
            }
        }
    }

    return [
        'visible' => $visible,
        'html' => $html,
    ];
}

/** @return array{visible:bool,rows:array<int,array<string,mixed>>} */
function ybb_sm_product_additional_info_payload(WC_Product $product, array $override): array
{
    $rows = ybb_sm_product_additional_rows($product);
    $visible = empty($override['hideAdditionalInfo']) && $rows !== [];

    return [
        'visible' => $visible,
        'rows' => $visible ? $rows : [],
    ];
}

function ybb_sm_product_find_wc(string $handle): ?WC_Product
{
    if (function_exists('ybb_home_wc_find_product_by_handle')) {
        $product = ybb_home_wc_find_product_by_handle($handle);
        if ($product instanceof WC_Product) {
            return $product;
        }
    }

    if (!function_exists('wc_get_products')) {
        return null;
    }

    $sku = strtoupper(str_replace(' ', '-', $handle));
    $ids = wc_get_products([
        'status' => ['publish', 'draft', 'private'],
        'sku' => $sku,
        'limit' => 1,
        'return' => 'ids',
    ]);
    if ($ids) {
        $product = wc_get_product($ids[0]);

        return $product instanceof WC_Product ? $product : null;
    }

    return null;
}

/** @return array<int, array<string, mixed>> */
function ybb_sm_product_live_variants(WC_Product $product): array
{
    if (!$product->is_type('variable')) {
        return [];
    }

    $out = [];
    foreach ($product->get_children() as $variationId) {
        $variation = wc_get_product($variationId);
        if (!$variation instanceof WC_Product_Variation) {
            continue;
        }

        $attrs = [];
        foreach ($variation->get_attributes() as $name => $value) {
            $label = wc_attribute_label($name, $product);
            $display = $value;
            if (taxonomy_exists($name) && $value) {
                $term = get_term_by('slug', $value, $name);
                if ($term && !is_wp_error($term)) {
                    $display = $term->name;
                }
            }
            if ($label && $display) {
                $attrs[] = [
                    'attribute' => (string) $label,
                    'value' => (string) $display,
                ];
            }
        }

        $spec = implode(' / ', array_column($attrs, 'value'));
        if ($spec === '') {
            $spec = (string) $variation->get_sku();
        }

        $regular = (float) $variation->get_regular_price();
        $sale = (float) $variation->get_sale_price();
        $price = $sale > 0 ? $sale : $regular;
        $compareAt = ($sale > 0 && $regular > $sale) ? $regular : null;

        $out[] = [
            'spec' => $spec,
            'sku' => (string) $variation->get_sku(),
            'wcId' => (int) $variation->get_id(),
            'price' => $price,
            'compareAtPrice' => $compareAt,
            'available' => $variation->is_in_stock() && $variation->is_purchasable(),
            'wcAttributes' => $attrs,
        ];
    }

    return $out;
}

function ybb_sm_product_price_from_wc(WC_Product $product): array
{
    $regular = (float) $product->get_regular_price();
    $sale = (float) $product->get_sale_price();
    if ($product->is_type('variable')) {
        $regular = (float) $product->get_variation_regular_price('min');
        $sale = (float) $product->get_variation_sale_price('min');
    }
    $price = $sale > 0 ? $sale : $regular;
    $compareAt = ($sale > 0 && $regular > $sale) ? $regular : null;

    return ['price' => $price, 'compareAtPrice' => $compareAt];
}

function ybb_sm_product_live_payload(string $handle, ?WC_Product $product = null): ?array
{
    $handle = sanitize_title($handle);
    if ($handle === '') {
        return null;
    }

    $product = $product instanceof WC_Product ? $product : ybb_sm_product_find_wc($handle);
    if (!$product instanceof WC_Product) {
        return null;
    }

    $override = ybb_sm_product_override_get($handle);
    $prices = ybb_sm_product_price_from_wc($product);
    $variants = ybb_sm_product_live_variants($product);
    $parentSku = (string) $product->get_sku();
    if ($parentSku === '') {
        $parentSku = strtoupper($handle);
    }

    return [
        'handle' => $handle,
        'parentSku' => $parentSku,
        'wcId' => (int) $product->get_id(),
        'wooStatus' => (string) $product->get_status(),
        'titles' => [
            'en' => (string) $product->get_name(),
            'zh' => $override['titleZh'] !== '' ? $override['titleZh'] : (string) $product->get_name(),
            'ja' => $override['titleJa'] !== '' ? $override['titleJa'] : (string) $product->get_name(),
        ],
        'price' => $prices['price'],
        'compareAtPrice' => $prices['compareAtPrice'],
        'available' => $product->is_in_stock() && $product->is_purchasable() && $product->get_status() === 'publish',
        'variants' => $variants,
        'frontHidden' => $override['frontHidden'],
        'content' => [
            'description' => ybb_sm_product_description_payload($product, $override),
            'additionalInfo' => ybb_sm_product_additional_info_payload($product, $override),
        ],
        'purchaseSlogan' => ybb_sm_product_purchase_slogan_payload($override),
        'pdpUrl' => home_url('/products/' . $handle),
        'syncedAt' => ybb_sm_synced_at(),
    ];
}

function ybb_sm_product_overrides_public(): array
{
    if (count(ybb_sm_product_overrides_all()) === 0) {
        ybb_sm_maybe_migrate_products();
    }

    $module = ybb_sm_products_module();
    $out = [];
    foreach ($module['overrides'] ?? [] as $handle => $row) {
        if (!is_array($row)) {
            continue;
        }
        $handle = sanitize_title((string) $handle);
        if ($handle === '') {
            continue;
        }
        $titleZh = trim((string) ($row['titleZh'] ?? ''));
        $titleJa = trim((string) ($row['titleJa'] ?? ''));
        $frontHidden = !empty($row['frontHidden']);
        $descriptionZh = trim((string) ($row['descriptionZh'] ?? ''));
        $descriptionJa = trim((string) ($row['descriptionJa'] ?? ''));
        $hideDescription = !empty($row['hideDescription']);
        $hideAdditionalInfo = !empty($row['hideAdditionalInfo']);
        $sloganEn = trim((string) ($row['sloganEn'] ?? ''));
        $sloganZh = trim((string) ($row['sloganZh'] ?? ''));
        $sloganJa = trim((string) ($row['sloganJa'] ?? ''));
        $hideSlogan = !empty($row['hideSlogan']);
        if (
            $titleZh === '' && $titleJa === '' && !$frontHidden
            && $descriptionZh === '' && $descriptionJa === ''
            && !$hideDescription && !$hideAdditionalInfo
            && $sloganEn === '' && $sloganZh === '' && $sloganJa === ''
            && !$hideSlogan
        ) {
            continue;
        }
        $out[$handle] = [
            'titleZh' => $titleZh,
            'titleJa' => $titleJa,
            'frontHidden' => $frontHidden,
            'descriptionZh' => $descriptionZh,
            'descriptionJa' => $descriptionJa,
            'hideDescription' => $hideDescription,
            'hideAdditionalInfo' => $hideAdditionalInfo,
            'sloganEn' => $sloganEn,
            'sloganZh' => $sloganZh,
            'sloganJa' => $sloganJa,
            'hideSlogan' => $hideSlogan,
        ];
    }

    return [
        'enabled' => !empty($module['enabled']),
        'overrides' => $out,
        'syncedAt' => ybb_sm_synced_at(),
    ];
}

function ybb_sm_product_save_override(string $handle, array $input): array|WP_Error
{
    if (!current_user_can('manage_options')) {
        return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
    }

    $forbidden = ['sku', 'wcId', 'price', 'variants', 'id', 'parentSku', 'descriptionEn'];
    foreach ($forbidden as $key) {
        if (array_key_exists($key, $input)) {
            return new WP_Error(
                'invalid_field',
                'Field "' . $key . '" cannot be overridden here.',
                ['status' => 400]
            );
        }
    }

    $handle = sanitize_title($handle);
    if ($handle === '') {
        return new WP_Error('invalid_handle', 'Invalid handle.', ['status' => 400]);
    }

    $titleZh = sanitize_text_field((string) ($input['titleZh'] ?? ''));
    $titleJa = sanitize_text_field((string) ($input['titleJa'] ?? ''));
    $frontHidden = !empty($input['frontHidden']);
    $descriptionZh = wp_kses_post((string) ($input['descriptionZh'] ?? ''));
    $descriptionJa = wp_kses_post((string) ($input['descriptionJa'] ?? ''));
    $hideDescription = !empty($input['hideDescription']);
    $hideAdditionalInfo = !empty($input['hideAdditionalInfo']);
    $sloganEn = ybb_sm_sanitize_slogan_text((string) ($input['sloganEn'] ?? ''));
    $sloganZh = ybb_sm_sanitize_slogan_text((string) ($input['sloganZh'] ?? ''));
    $sloganJa = ybb_sm_sanitize_slogan_text((string) ($input['sloganJa'] ?? ''));
    $hideSlogan = !empty($input['hideSlogan']);

    $before = ybb_sm_products_module();
    $overrides = ybb_sm_product_overrides_all();

    if (
        $titleZh === '' && $titleJa === '' && !$frontHidden
        && $descriptionZh === '' && $descriptionJa === ''
        && !$hideDescription && !$hideAdditionalInfo
        && $sloganEn === '' && $sloganZh === '' && $sloganJa === ''
        && !$hideSlogan
    ) {
        unset($overrides[$handle]);
    } else {
        $overrides[$handle] = [
            'titleZh' => $titleZh,
            'titleJa' => $titleJa,
            'frontHidden' => $frontHidden,
            'descriptionZh' => $descriptionZh,
            'descriptionJa' => $descriptionJa,
            'hideDescription' => $hideDescription,
            'hideAdditionalInfo' => $hideAdditionalInfo,
            'sloganEn' => $sloganEn,
            'sloganZh' => $sloganZh,
            'sloganJa' => $sloganJa,
            'hideSlogan' => $hideSlogan,
            'updatedAt' => gmdate('c'),
        ];
    }

    ybb_sm_product_overrides_save($overrides);

    $all = ybb_sm_get_all();
    $products = $before;
    unset($products['overrides']);
    $products['enabled'] = true;
    $all['products'] = $products;
    update_option(YBB_SM_OPTION, $all);

    if (function_exists('ybb_sm_audit_log_config_save')) {
        ybb_sm_audit_log_config_save('products', $before, $products);
    }

    return ybb_sm_product_live_payload($handle) ?? [
        'handle' => $handle,
        'titles' => ['en' => '', 'zh' => $titleZh, 'ja' => $titleJa],
        'frontHidden' => $frontHidden,
        'syncedAt' => ybb_sm_synced_at(),
    ];
}

function ybb_sm_product_index_meta(): array
{
    $module = ybb_sm_products_module();

    return is_array($module['productIndex'] ?? null) ? $module['productIndex'] : [];
}

function ybb_sm_product_static_handles(): array
{
    $stored = get_option('ybb_sm_static_product_handles', null);
    if (is_array($stored)) {
        return array_values($stored);
    }

    $meta = ybb_sm_product_index_meta();
    $legacy = $meta['staticHandles'] ?? [];

    return is_array($legacy) ? array_values($legacy) : [];
}

/** @param list<string> $handles */
function ybb_sm_product_static_handles_set(array $handles): void
{
    $clean = array_values(array_unique(array_filter(array_map(
        static fn ($h) => sanitize_title((string) $h),
        $handles
    ))));
    update_option('ybb_sm_static_product_handles', $clean, false);
}

function ybb_sm_product_static_handle_set(): array
{
    $handles = ybb_sm_product_static_handles();

    return array_fill_keys($handles, true);
}

function ybb_sm_product_in_static_export(string $handle): bool
{
    $handles = ybb_sm_product_static_handles();
    if ($handles === []) {
        return true;
    }

    return in_array(sanitize_title($handle), $handles, true);
}

function ybb_sm_product_update_index_meta(string $buildId = '', int $productCount = 0, array $handles = []): void
{
    $all = ybb_sm_get_all();
    $products = ybb_sm_products_module();
    $staticHandles = array_values(array_unique(array_filter(array_map(
        static fn ($h) => sanitize_title((string) $h),
        $handles
    ))));
    $products['productIndex'] = [
        'lastBuiltAt' => gmdate('c'),
        'lastBuildId' => sanitize_text_field($buildId),
        'productCount' => max(0, $productCount),
    ];
    if ($staticHandles !== []) {
        ybb_sm_product_static_handles_set($staticHandles);
    }
    $all['products'] = $products;
    update_option(YBB_SM_OPTION, $all);
    if (function_exists('ybb_sm_product_catalog_flush_cache')) {
        ybb_sm_product_catalog_flush_cache();
    } else {
        delete_transient('ybb_sm_product_catalog_v1');
    }
}
