<?php

if (!defined('ABSPATH')) {
    exit;
}

function ybb_sm_navigation_public(): array
{
    $nav = ybb_sm_get_module('navigation');
    $primary = [];
    foreach ($nav['primaryNav'] ?? [] as $item) {
        if (empty($item['enabled'])) {
            continue;
        }
        $row = [
            'id' => (string) ($item['id'] ?? ''),
            'label' => (string) ($item['label'] ?? ''),
            'labels' => $item['labels'] ?? [],
            'href' => (string) ($item['href'] ?? ''),
        ];
        if (!empty($item['megaMenu']) && is_array($item['megaMenu'])) {
            $row['megaMenu'] = $item['megaMenu'];
        }
        $primary[] = $row;
    }

    $visibleCollections = [];
    foreach ($primary as $item) {
        $hrefs = [(string) ($item['href'] ?? '')];
        foreach ($item['megaMenu']['children'] ?? [] as $child) {
            if (is_array($child) && !empty($child['href'])) {
                $hrefs[] = (string) $child['href'];
            }
        }
        foreach ($hrefs as $href) {
            if (preg_match('#^/collections/([^/?#]+)#', $href, $matches)) {
                $visibleCollections[rawurldecode($matches[1])] = true;
            }
        }
    }

    $footer = $nav['footer'] ?? [];
    $filterLinks = static function (array $rows) use ($visibleCollections): array {
        $out = [];
        foreach ($rows as $row) {
            if (isset($row['enabled']) && empty($row['enabled'])) {
                continue;
            }
            $href = (string) ($row['href'] ?? '');
            if (preg_match('#^/collections/([^/?#]+)#', $href, $matches)) {
                $handle = rawurldecode($matches[1]);
                if (!isset($visibleCollections[$handle])) {
                    continue;
                }
            }
            $out[] = [
                'label' => (string) ($row['label'] ?? ''),
                'labels' => $row['labels'] ?? [],
                'href' => $href,
            ];
        }

        return $out;
    };

    $social = [];
    foreach ($footer['social'] ?? [] as $row) {
        if (empty($row['enabled'])) {
            continue;
        }
        $social[] = [
            'label' => (string) ($row['label'] ?? ''),
            'href' => (string) ($row['href'] ?? ''),
        ];
    }

    return [
        'primaryNav' => $primary,
        'footer' => [
            'quickLinks' => $filterLinks($footer['quickLinks'] ?? []),
            'information' => $filterLinks($footer['information'] ?? []),
            'policies' => $filterLinks($footer['policies'] ?? []),
            'social' => $social,
        ],
        'syncedAt' => ybb_sm_synced_at(),
    ];
}
