<?php
/**
 * Plugin Name: YBB Contact Inquiry
 * Description: REST endpoint for static-site contact form → wp_mail (Site Mailer).
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

const YBB_CONTACT_OPTION = 'ybb_contact_settings';
const YBB_CONTACT_RATE_PREFIX = 'ybb_contact_rate_';

function ybb_contact_defaults(): array
{
    return [
        'recipientEmail' => 'carp-ybb@outlook.com',
        'rateLimitPerHour' => 5,
    ];
}

function ybb_contact_get_settings(): array
{
    $defaults = ybb_contact_defaults();
    $stored = get_option(YBB_CONTACT_OPTION, []);
    if (!is_array($stored)) {
        $stored = [];
    }

    $email = sanitize_email((string) ($stored['recipientEmail'] ?? $defaults['recipientEmail']));
    if (function_exists('ybb_sm_contact_get_raw')) {
        $contact = ybb_sm_contact_get_raw();
        $smEmail = sanitize_email((string) ($contact['salesEmail'] ?? ''));
        if ($smEmail !== '') {
            $email = $smEmail;
        }
    }
    if ($email === '') {
        $email = $defaults['recipientEmail'];
    }

    return [
        'recipientEmail' => $email,
        'rateLimitPerHour' => max(1, (int) ($stored['rateLimitPerHour'] ?? $defaults['rateLimitPerHour'])),
    ];
}

function ybb_contact_subject_labels(): array
{
    return [
        'wholesale' => 'Wholesale RFQ',
        'oem' => 'OEM / ODM inquiry',
        'samples' => 'Sample request',
        'other' => 'Other',
    ];
}

function ybb_contact_client_ip(): string
{
    $candidates = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($candidates as $key) {
        if (empty($_SERVER[$key])) {
            continue;
        }
        $raw = (string) $_SERVER[$key];
        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $raw = trim(explode(',', $raw)[0]);
        }
        if (filter_var($raw, FILTER_VALIDATE_IP)) {
            return $raw;
        }
    }
    return '0.0.0.0';
}

function ybb_contact_rate_limited(string $ip, int $limit): bool
{
    $key = YBB_CONTACT_RATE_PREFIX . md5($ip);
    $count = (int) get_transient($key);
    if ($count >= $limit) {
        return true;
    }
    set_transient($key, $count + 1, HOUR_IN_SECONDS);
    return false;
}

function ybb_contact_sanitize_payload($request): array|WP_Error
{
    $body = $request->get_json_params();
    if (!is_array($body)) {
        return new WP_Error('ybb_contact_invalid', 'Invalid JSON body.', ['status' => 400]);
    }

    // Honeypot — bots fill hidden "website" field.
    if (!empty($body['website'])) {
        return new WP_Error('ybb_contact_spam', 'Submission rejected.', ['status' => 400]);
    }

    $name = sanitize_text_field((string) ($body['name'] ?? ''));
    $email = sanitize_email((string) ($body['email'] ?? ''));
    $company = sanitize_text_field((string) ($body['company'] ?? ''));
    $subject = sanitize_key((string) ($body['subject'] ?? ''));
    $message = sanitize_textarea_field((string) ($body['message'] ?? ''));
    $locale = sanitize_key((string) ($body['locale'] ?? 'en'));

    if ($name === '' || strlen($name) > 120) {
        return new WP_Error('ybb_contact_name', 'Name is required.', ['status' => 400]);
    }
    if ($email === '' || !is_email($email)) {
        return new WP_Error('ybb_contact_email', 'Valid email is required.', ['status' => 400]);
    }
    if ($company === '' || strlen($company) > 160) {
        return new WP_Error('ybb_contact_company', 'Company is required.', ['status' => 400]);
    }
    if (!array_key_exists($subject, ybb_contact_subject_labels())) {
        return new WP_Error('ybb_contact_subject', 'Invalid subject.', ['status' => 400]);
    }
    if ($message === '' || strlen($message) < 10 || strlen($message) > 5000) {
        return new WP_Error('ybb_contact_message', 'Message must be 10–5000 characters.', ['status' => 400]);
    }
    if (!in_array($locale, ['en', 'zh', 'ja'], true)) {
        $locale = 'en';
    }

    return compact('name', 'email', 'company', 'subject', 'message', 'locale');
}

function ybb_contact_send_mail(array $data): bool
{
    $settings = ybb_contact_get_settings();
    $subjectLabel = ybb_contact_subject_labels()[$data['subject']] ?? $data['subject'];
    $siteName = get_bloginfo('name') ?: 'YBB';
    $mailSubject = sprintf(
        '[%s] %s — %s',
        $siteName,
        $subjectLabel,
        $data['company']
    );

    $lines = [
        'New contact inquiry from carp-ybb.com',
        '',
        'Name: ' . $data['name'],
        'Email: ' . $data['email'],
        'Company: ' . $data['company'],
        'Subject: ' . $subjectLabel,
        'Locale: ' . strtoupper($data['locale']),
        'IP: ' . ybb_contact_client_ip(),
        '',
        'Message:',
        $data['message'],
    ];
    $body = implode("\n", $lines);

    $headers = [
        'Content-Type: text/plain; charset=UTF-8',
        sprintf('Reply-To: %s <%s>', $data['name'], $data['email']),
    ];

    return wp_mail($settings['recipientEmail'], $mailSubject, $body, $headers);
}

function ybb_contact_handle_submit(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    $settings = ybb_contact_get_settings();
    $ip = ybb_contact_client_ip();
    if (ybb_contact_rate_limited($ip, $settings['rateLimitPerHour'])) {
        return new WP_Error(
            'ybb_contact_rate_limit',
            'Too many submissions. Please try again later.',
            ['status' => 429]
        );
    }

    $data = ybb_contact_sanitize_payload($request);
    if (is_wp_error($data)) {
        return $data;
    }

    $sent = ybb_contact_send_mail($data);
    if (!$sent) {
        $settings = ybb_contact_get_settings();
        return new WP_Error(
            'ybb_contact_mail_failed',
            sprintf(
                'Unable to send inquiry. Please email %s directly.',
                $settings['recipientEmail']
            ),
            ['status' => 500]
        );
    }

    return rest_ensure_response([
        'ok' => true,
        'message' => 'Inquiry sent.',
    ]);
}

add_action('rest_api_init', function () {
    register_rest_route('ybb/v1', '/contact-inquiry', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => 'ybb_contact_handle_submit',
    ]);
});

add_action('admin_init', function () {
    register_setting('ybb_contact_group', YBB_CONTACT_OPTION, [
        'type' => 'array',
        'sanitize_callback' => function ($input) {
            $defaults = ybb_contact_defaults();
            $input = is_array($input) ? $input : [];
            $email = sanitize_email((string) ($input['recipientEmail'] ?? $defaults['recipientEmail']));
            return [
                'recipientEmail' => $email !== '' ? $email : $defaults['recipientEmail'],
                'rateLimitPerHour' => max(1, (int) ($input['rateLimitPerHour'] ?? $defaults['rateLimitPerHour'])),
            ];
        },
        'default' => ybb_contact_defaults(),
    ]);
});

add_action('admin_menu', function () {
    add_options_page(
        'YBB Contact',
        'YBB Contact',
        'manage_options',
        'ybb-contact',
        function () {
            if (!current_user_can('manage_options')) {
                return;
            }
            $settings = ybb_contact_get_settings();
            ?>
            <div class="wrap">
                <h1>YBB Contact</h1>
                <p>静态站 Contact 表单通过 <code>POST /wp-json/ybb/v1/contact-inquiry</code> 提交，邮件经 <code>wp_mail()</code> 发出（Site Mailer 接管投递）。</p>
                <p><strong>推荐：</strong>在 <a href="<?php echo esc_url(admin_url('admin.php?page=ybb-site-manager&tab=contact')); ?>">YBB 站点管理 → 联系页</a> 编辑销售邮箱与页面文案；保存后会同步到本页收件箱。</p>
                <form method="post" action="options.php">
                    <?php settings_fields('ybb_contact_group'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="ybb_contact_recipient">收件邮箱</label></th>
                            <td>
                                <input type="email" class="regular-text" id="ybb_contact_recipient"
                                       name="<?php echo esc_attr(YBB_CONTACT_OPTION); ?>[recipientEmail]"
                                       value="<?php echo esc_attr($settings['recipientEmail']); ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ybb_contact_rate">每小时同 IP 上限</label></th>
                            <td>
                                <input type="number" min="1" max="50" id="ybb_contact_rate"
                                       name="<?php echo esc_attr(YBB_CONTACT_OPTION); ?>[rateLimitPerHour]"
                                       value="<?php echo esc_attr((string) $settings['rateLimitPerHour']); ?>" />
                            </td>
                        </tr>
                    </table>
                    <?php submit_button('保存'); ?>
                </form>
            </div>
            <?php
        }
    );
});
